It doesn't seem to be possible to have a patched version of a submodule within a repo.

Thanks to Tim Schuerewegen for his work to produce the modified code


To rebuild libdwi simple example to include the USB VID/PID's for the Maple USB devices, apply the diff file as a patch to the sources in the pbatard_libwdi folder


See also the libwdi-extra-files folder supplied by Tim Schuerewegen, required to build in Visial Studio on Windows

